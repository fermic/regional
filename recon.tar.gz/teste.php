<!-- Painel de Controle de Cache (apenas desenvolvimento) -->
<div id="cache-control" style="position: fixed; bottom: 20px; left: 20px; z-index: 9999; display: none;">
    <div class="card shadow" style="width: 300px;">
        <div class="card-header bg-dark text-white">
            <strong>🛠️ Controle de Cache</strong>
            <button class="btn-close btn-close-white float-end btn-sm" onclick="document.getElementById('cache-control').style.display='none'"></button>
        </div>
        <div class="card-body">
            <button class="btn btn-danger btn-sm w-100 mb-2" onclick="limparTodoCache()">
                🗑️ Limpar Todo Cache
            </button>
            <button class="btn btn-warning btn-sm w-100 mb-2" onclick="atualizarServiceWorker()">
                🔄 Forçar Atualização SW
            </button>
            <button class="btn btn-info btn-sm w-100 mb-2" onclick="desregistrarServiceWorker()">
                ❌ Desregistrar SW
            </button>
            <button class="btn btn-secondary btn-sm w-100" onclick="verStatusCache()">
                📊 Ver Status
            </button>
            <div id="cache-status" class="mt-2 small"></div>
        </div>
    </div>
</div>

<!-- Botão flutuante para abrir painel (remover em produção) -->
<button class="btn btn-dark btn-sm" 
        style="position: fixed; bottom: 20px; left: 20px; z-index: 9998;"
        onclick="document.getElementById('cache-control').style.display='block'">
    🛠️
</button>

<script>
// Funções de controle de cache
async function limparTodoCache() {
    if (!confirm('Isso removerá TODO o cache. Continuar?')) return;
    
    try {
        // Limpar caches do Service Worker
        if ('caches' in window) {
            const cacheNames = await caches.keys();
            await Promise.all(
                cacheNames.map(cacheName => {
                    console.log('Deletando cache:', cacheName);
                    return caches.delete(cacheName);
                })
            );
        }
        
        // Limpar localStorage
        if (confirm('Limpar também o localStorage (dados offline)?')) {
            localStorage.clear();
        }
        
        // Recarregar sem cache
        alert('Cache limpo! A página será recarregada.');
        window.location.reload(true);
        
    } catch (error) {
        console.error('Erro ao limpar cache:', error);
        alert('Erro ao limpar cache: ' + error.message);
    }
}

async function atualizarServiceWorker() {
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.getRegistration();
            if (registration) {
                registration.update();
                alert('Service Worker atualizado! Recarregue a página.');
            }
        } catch (error) {
            console.error('Erro ao atualizar SW:', error);
        }
    }
}

async function desregistrarServiceWorker() {
    if (!confirm('Isso desativará o funcionamento offline. Continuar?')) return;
    
    if ('serviceWorker' in navigator) {
        try {
            const registrations = await navigator.serviceWorker.getRegistrations();
            for (let registration of registrations) {
                await registration.unregister();
            }
            alert('Service Worker desregistrado! Recarregue a página.');
            window.location.reload(true);
        } catch (error) {
            console.error('Erro ao desregistrar SW:', error);
        }
    }
}

async function verStatusCache() {
    const status = document.getElementById('cache-status');
    let html = '<strong>Status do Cache:</strong><br>';
    
    // Service Worker
    if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration) {
            html += '✅ Service Worker: Ativo<br>';
            html += `Estado: ${registration.active ? 'Running' : 'Stopped'}<br>`;
        } else {
            html += '❌ Service Worker: Inativo<br>';
        }
    }
    
    // Caches
    if ('caches' in window) {
        const cacheNames = await caches.keys();
        html += `📦 Caches: ${cacheNames.length}<br>`;
        for (let name of cacheNames) {
            const cache = await caches.open(name);
            const keys = await cache.keys();
            html += `- ${name}: ${keys.length} arquivos<br>`;
        }
    }
    
    // localStorage
    const localStorageSize = new Blob(Object.values(localStorage)).size;
    html += `💾 localStorage: ${(localStorageSize / 1024).toFixed(2)} KB<br>`;
    
    status.innerHTML = html;
}

// Adicionar listener para recarregar quando houver novo SW
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (confirm('Nova versão disponível! Recarregar página?')) {
            window.location.reload();
        }
    });
}

// Atalho de teclado para abrir painel (Ctrl+Shift+C)
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
        const panel = document.getElementById('cache-control');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
});
</script>